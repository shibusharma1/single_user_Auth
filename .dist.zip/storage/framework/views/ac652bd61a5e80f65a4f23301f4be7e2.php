<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo e(auth()->user()->name); ?></h2>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\shibu\OneDrive\Desktop\laravel Auth\Single_User_Auth\resources\views/dashboard.blade.php ENDPATH**/ ?>